#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <fcntl.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>
 
#define N 4396
 
typedef struct sockaddr SA;
 
void file_ls(int,char *);
void file_cd(int,char *,char *);
void file_get(int,char *, char *);
void file_put(int,char *,char *);
void file_mkd(int,char *,char *);
char* file_mode(mode_t m,char* str)
{
	if(S_ISREG(m))
		str[0] = '-';
	else if(S_ISDIR(m))
		str[0] = 'd';
	else if(S_ISCHR(m))
		str[0] = 'c';
	else if(S_ISBLK(m))
		str[0] = 'b';
	else if(S_ISFIFO(m))
		str[0] = 'q';
	else if(S_ISLNK(m))
		str[0] = 'l';
	else if(S_ISSOCK(m))
		str[0] = 's';
	else 
		str[0] = '?';

	str[1] = '\0';

	strcat(str,S_IRUSR&m?"r":"-");
	strcat(str,S_IWUSR&m?"w":"-");
	strcat(str,S_IXUSR&m?"x":"-");

	strcat(str,S_IRGRP&m?"r":"-");
	strcat(str,S_IWGRP&m?"w":"-");
	strcat(str,S_IXGRP&m?"x":"-");
	
	strcat(str,S_IROTH&m?"r":"-");
	strcat(str,S_IWOTH&m?"w":"-");
	strcat(str,S_IXOTH&m?"x":"-");

	return str;
}
int main(int arg, char *argv[])
{
    int ser_sockfd,cli_sockfd;
    struct sockaddr_in ser_addr,cli_addr;
    int ser_len, cli_len;
    char str [N];
    bzero(str,N);
 
    if((ser_sockfd=socket(AF_INET, SOCK_STREAM, 0) ) < 0)
    {
		perror("socket");
        return -1;
    }
 
    bzero(&ser_addr,sizeof(ser_addr));
    ser_addr.sin_family = AF_INET;
    ser_addr.sin_addr.s_addr = htonl(INADDR_ANY);
                                                
    ser_addr.sin_port = htons (8885);
    ser_len = sizeof(ser_addr);
    
    if((bind(ser_sockfd, (SA *)&ser_addr, ser_len)) < 0)
    {
		perror("bind");
        return -1;
    }
    if(listen(ser_sockfd, 5) < 0)
    {
		perror("listen");
        return -1;
    }
 
    bzero(&cli_addr, sizeof(cli_addr));
    ser_len = sizeof(cli_addr);
 	char arr[N]=".";
 
    while(1)
    {
        printf("server_ftp>");
        if((cli_sockfd=accept(ser_sockfd, (SA *)&cli_addr, &cli_len)) < 0)
        {
			perror("accept");
            exit(1);
        }
        if(read(cli_sockfd, str, N) < 0)
        {
			perror("read");
            exit(1);
        }
 
        if(strncmp(str,"ls",2) == 0)
        {
            file_ls(cli_sockfd,arr);
        }else if(strncmp(str,"cd",2)==0)
		{
			file_cd(cli_sockfd,arr,str+3);
		}else if(strncmp(str,"get", 3) == 0 )
        {
            file_get(cli_sockfd,arr, str+4);
        }else if(strncmp(str, "put", 3) == 0)
        {
            file_put(cli_sockfd,arr ,str+4);
        }else if(strncmp(str,"mkdir",5)==0)
        {
            file_mkd(cli_sockfd,arr,str+6);
        }else
        {
            printf("Error!Command Error!\n");
        }
    }
 
    return 0;
}
 
void file_ls(int sockfd,char* arr)
{
    DIR * dp =NULL;
    struct dirent *dir = NULL;
    char str[N] ;
    bzero(str, N);
    char abc[N]={};
    if((dp=opendir(arr)) == NULL)
    {
		strcpy(abc,"opendir error\n");
        write(sockfd,abc,strlen(abc)+1);
        return;
    }
	char info[N]={};
 	for(struct dirent *dir=readdir(dp);NULL!=dir;dir=readdir(dp))
	{
		struct stat buf={};
		if(stat(dir->d_name,&buf))
		{
			perror("stat");
		}
		file_mode(buf.st_mode,info);
		if('d' == info[0])
		{
			sprintf(str,"%s \33[1;34m %s\033[0m",str,dir->d_name);
		}else if('x'==info[3])
		{
			sprintf(str,"%s \33[1;32m %s\033[0m",str,dir->d_name);
		}
		else
		{
			sprintf(str,"%s %s",str,dir->d_name);
		}
	}

        if(write(sockfd, str, strlen(str)+1) < 0 )
        {
			strcpy(abc,"write error\n");
            write(sockfd,abc,strlen(abc)+1);
            return;
        }
 
    closedir(dp);
    close(sockfd);
    return ;
}
void file_cd(int sockfd,char* arr,char* filename)
{
    printf("get pathname : [ %s ]\n",filename);
	
	char temp[N]={};
	sprintf(temp,"%s/%s",arr,filename);
	puts(temp);
	
	DIR* dp = opendir(temp);
	if(NULL==dp)
	{
		char str1[N]="error\n";
		if(0>write(sockfd,str1,N))
		{
			perror("write");
			exit(1);
		}
		return;
	}
	char str2[N]="success\n";
	if(0>write(sockfd,str2,N))
	{
		perror("write");
		exit(1);
	}
	strcpy(arr,temp);
	close(sockfd);
	return;
}
void file_get(int sockfd,char *arr ,char *filename)
{
    int fd, ret;
    char buf[N];
	memset(buf,0,sizeof(buf));
 	char temp[N]={};
    
    printf("get filename : [ %s ]\n",filename);
	sprintf(temp,"%s/%s",arr,filename);
    
    if((fd=open(temp, O_RDONLY)) < 0)
    {
		perror("open");
        if(write(sockfd, buf, strlen(buf)+1) <0)
        {
			perror("write");
            exit(1);
        }
        return ;
    }   
    while((ret=read(fd, buf, N )) > 0)
    {
        if(write(sockfd, buf, ret) < 0)
        {
            close(fd);
            exit(1);
        }
		memset(buf,0,sizeof(buf));
    }
    close(fd);
    close(sockfd);
 
    return ;
}
 
void file_put(int sockfd,char *arr, char *filename)
{
    int fd, ret;
    char buf[N];
    bzero(buf, N);
 	char temp[N]={};
	sprintf(temp,"%s/%s",arr,filename);
    printf("get filename : [ %s ]\n",filename);
    if((fd=open(temp, O_WRONLY|O_CREAT|O_TRUNC, 0644)) < 0)
    {
		perror("open");
        return ;
    }
 
    while((ret=read(sockfd, buf, N)) > 0)
    {
        if(write(fd, buf, ret) < 0)
        {
			perror("write");
            close(fd);
            exit(1);
        }
    }
    close(fd);
    close(sockfd);
 
    return ;
}
void file_mkd(int sockfd,char *arr,char *filename)
{
    char temp[N]={};
    char buf[N]={};
    sprintf(buf,"%s/%s",arr,filename);
    if(-1!=access(buf,F_OK))
    {
        strcpy(temp,"file exit");
        write(sockfd,temp,strlen(temp)+1);
        return;
    }
    if(0>mkdir(buf,0644))
    {
        strcpy(temp,"creat error");
        write(sockfd,temp,strlen(temp)+1);
        return;
    }
    strcpy(temp,"success");
    write(sockfd,temp,strlen(temp)+1);
    return;
}
