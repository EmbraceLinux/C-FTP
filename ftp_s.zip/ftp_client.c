#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <fcntl.h>
 
#define N 1024
 
typedef struct sockaddr SA;
 
void file_exit();
void file_cd(struct sockaddr_in,char *);
void file_ls(struct sockaddr_in, char *);
void file_get(struct sockaddr_in , char *);
void file_put(struct sockaddr_in , char *);
void file_mkd(struct sockaddr_in ,char *); 
int main(int argc, char *argv[])
{
    char str[N];
    struct sockaddr_in addr;
    bzero(&addr, sizeof(addr));
    addr.sin_family = AF_INET;      
    addr.sin_addr.s_addr = inet_addr("116.62.166.58"); 
    addr.sin_port = htons(8885);  
    int len = sizeof(addr);
 
    while(1)
    {
        printf("ftp>");
        bzero(str,N);
        if(fgets(str,N,stdin) == NULL)
        {
			perror("fgets");
            return -1;
        }
 
        str[strlen(str)-1]='\0';
        printf("Input Command Is [ %s ]\n",str);
 
        if(strcmp(str, "exit") == 0)
        {
            file_exit();
            exit(0); 
        }else if(strcmp(str,"ls") == 0)
        {
            file_ls(addr, str);
        }else if(strncmp(str, "cd" , 2)==0)
		{
			file_cd(addr,str);
		}else if(strncmp(str, "get" , 3) == 0)
        {
            file_get(addr, str);
        }else if(strncmp(str, "put", 3) ==0 )
        {
            file_put(addr, str);
        }else if(strncmp(str,"mkdir",5)==0)
		{
			file_mkd(addr,str);
		}else
        {
            printf("Command Is Error!Please Try Again!\n");
        }
 
    }
    return 0;
}
 
 
void file_exit()
{
    printf("ByeBye!\n");
}
void file_mkd(struct sockaddr_in addr,char *str)
{
    int sockfd;
    if((sockfd=socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
		perror("socket");
        exit(1);
    }
 
    if(connect(sockfd, (SA *)&addr, sizeof(addr)) < 0)
    {
		perror("connect");
        exit(1);
    }
    if(write(sockfd, str, strlen(str)+1) < 0)
    {
		perror("write");
        exit(1);
    }
 
    if(read(sockfd, str, N) > 0) 
    {                                  
        printf("%s",str);
    }
    printf("\n");
 
    close(sockfd);
    return ;
}
void file_ls(struct sockaddr_in addr, char *str)
{
    int sockfd;
    if((sockfd=socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
		perror("socket");
        exit(1);
    }
 
    if(connect(sockfd, (SA *)&addr, sizeof(addr)) < 0)
    {
		perror("connect");
        exit(1);
    }
    if(write(sockfd, str, strlen(str)+1) < 0)
    {
		perror("write");
        exit(1);
    }
 
    while(read(sockfd, str, N) > 0) 
    {                                  
        printf(" %s ",str);
    }
    printf("\n");
 
    close(sockfd);
    return ;
}
void file_cd(struct sockaddr_in addr,char* str)
{
	int sockfd=socket(AF_INET,SOCK_STREAM,0);
	if(0>sockfd)
	{
		perror("socket");
		exit(1);
	}
	if(connect(sockfd,(SA *)&addr,sizeof(addr))<0)
	{
		perror("connect");
		exit(1);
	}
	if(write(sockfd,str,N)<0)
	{
		perror("write");
		exit(1);
	}
    if(read(sockfd, str, N) > 0) 
    {                                  
        printf(" %s ",str);
    }

	close(sockfd);

	return;
}
void file_get(struct sockaddr_in addr, char *str)
{
    int fd;
    int sockfd;
    char buf[N]={};
    int ret;
    if((sockfd=socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
		perror("socket");
        exit(1);
    }
    if(connect(sockfd, (SA *)&addr, sizeof(addr)) < 0)
    {
		perror("connect");
        exit(1);
    }
    if(write(sockfd, str, strlen(str)+1) < 0)
    {
		perror("write");
        exit(1);
    }
    if((fd=open(str+4, O_WRONLY|O_CREAT|O_TRUNC, 0644)) < 0)
    {
		perror("open");
        exit(1);
    }
    while((ret=read(sockfd, buf, N)) > 0)
    {
        if(write(fd, buf, strlen(buf)+1) < 0)
        {
			perror("write");
        }
		memset(buf,0,sizeof(buf));
    }
 
    close(fd);
    close(sockfd);
 
    return ;
 
}
void file_put(struct sockaddr_in addr, char *str)
{
    int fd;
    int sockfd;
    char buf[N];
    int ret;
    if((sockfd=socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("socket");
        exit(1);
    }
    if(connect(sockfd, (SA *)&addr, sizeof(addr)) < 0)
    {
        perror("connect");
        exit(1);
    }
    if(write(sockfd, str, strlen(str)+1)<0)
    {
        perror("wrtie");
        exit(1);
    }
    if((fd=open(str+4, O_RDONLY)) < 0)
    {
        perror("open");
        exit(1);
    }
    while((ret=read(fd, buf, N)) > 0)
    {
        if(write(sockfd, buf, ret) < 0)
        {
			perror("write");
        }
    }
 
    close(fd);
    close(sockfd);
 
    return ;
}
